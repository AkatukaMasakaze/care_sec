# リアルタイムAI統合 作業メモ(中断時の再開用)

2026-11-05 に **caregiver_safety のリアルタイムAI を ai2 の `/debug/camera/` へ統合**する作業を
実施し、中止した際の状況を記録します。次回はこのファイルと「再開手順」から再開してください。

---

## 1. 実装済み(コードは完成・動作確認済み)

| ファイル | 変更内容 |
|---|---|
| `core/ai_engine.py` | **新規**。リアルタイム解析エンジン(MediaPipe Pose → 30フレーム姿勢系列 → 転倒/状態LSTM)。骨格・日本語overlay描画、`Alert` 生成、バックグラウンドスレッド管理 |
| `core/camera_service.py` | `read_frame(index)` を追加(解析用にBGRフレームを取得) |
| `core/views.py` | `debug_camera_stream()` を解析済みJPEG配信に変更、`debug_camera_ai_status()` を追加 |
| `config/urls.py` | `/debug/camera/ai/` を追加 |
| `config/settings.py` | `AI_REALTIME_ENABLED` / `AI_MODEL_DIR` / `AI_ANALYSIS_FPS` / `AI_JPEG_QUALITY` / `AI_ALERT_CAMERA_ID` / `AI_SIMULATOR_ENABLED` を追加 |
| `core/apps.py` | `AI_SIMULATOR_ENABLED=False` でデモ用シミュレーターを起動しない |
| `templates/debug/camera.html` | 「リアルタイムAI解析」ステータスカードを追加 |
| `static/js/debug_camera.js` | AI状態の1秒ポーリング、停止時のMJPEG接続切断(データURI上書き) |
| `static/css/style.css` | `.ai-status-*` スタイル追加 |
| `ai_models/` | `pose_landmarker_full.task` / `fall_detection_lstm.keras` / `state_detection_lstm.keras` / `state_labels.npy` + `README.md` |
| `requirements.txt` / `requirements-windows.txt` | tensorflow / mediapipe / pillow / opencv-contrib-python を追加(headless版は mediapipe と競合するため削除) |
| `README.md` | 統合の仕組み・設定・注意点を追記 |

### 環境
- `ai2/.venv` に **導入済み**: tensorflow 2.21.0 / mediapipe 0.10.32 / pillow 12.3.0 / opencv-contrib-python 5.0.0.93
- Python 3.13.17(caregiver_safety の venv と同一)

### 確認済みの動作
- カメラ検知: `index 0 / Web Camera - HD / 480×640 / 30fps`(このマシンは1台のみ)
- `/debug/camera/` の「表示開始」→ 骨格 + 日本語overlay(状態/判定/危険度/足/無動作)付き映像を配信
- 解析 **9.5〜9.8fps**(`AI_ANALYSIS_FPS=10` に到達)
- 実AIによる転倒検知 → `Alert` 作成 → `/api/alerts/` ポーリング → 画面上の「🚨 異常検知」バナー通知を確認
- 「停止 → 表示開始」の再起動(セッションIDによる競合対策後)に成功
- `manage.py check` / `manage.py verify_pages` ともに **全ページOK**
- `AI_SIMULATOR_ENABLED=False` 起動時の切替確認 OK

### 中で見つけた重要ポイント(再実装時に再発させないこと)
1. **推論は `tf.function` でグラフ化すること**
   `model.predict()` は約160ms/フレーム、`model(x, training=False)` の直接呼び出しは約400ms。
   `tf.function` 化すると **約7ms**。これで10fpsが出ている。
2. **MediaPipe の landmarker を `close()` しないこと**
   `_models` にキャッシュして再利用するため、close すると2回目以降が動かない。
3. **`detect_for_video` のタイムスタンプは単調増加させること**
   `max(int(time.monotonic()*1000), 前回値+1)` を使用(再開時に0へ巻き戻さない)。
4. **変数名 `connections` は使わない**
   Django の `django.db.connections` と衝突した。MediaPipe 側は `pose_connections`。
   DB側は `from django.db import close_old_connections` を使う(`connections.close_old_connections()` は存在しない)。
5. **Alert の信頼度は 0.0〜1.0** で保存する(百分率で入れると `confidence_percent` が壊れる)。
6. **`attach()` はセッションIDを返し、`detach(device, session)` に渡す**
   「停止→表示開始」時、古い接続の停止処理が新しい解析を止めてしまうのを防ぐ。
7. **「停止」ボタンはブラウザがMJPEG接続を切断しない**ため、
   `img.src` を透明なデータURIに上書きしてから `removeAttribute` する必要がある。

---

## 2. 未完了・要確認

| # | 内容 | 状況 |
|---|---|---|
| 1 | **無動作(`suspicious`)アラートの実環境検証** | **未検証(ユーザー判断でスキップ)**。カメラの前で30秒静止 → `AISettings.stillness_seconds`(既定30秒)で発火するか、の確認が残る |
| 2 | `AI_REALTIME_ENABLED=False` の実機確認 | **✅ 検証済み(2026-11-06)**。`False` でAIカード非表示・生映像のみ配信を確認後、`True` に戻して解析復帰も確認 |
| 3 | 誤検知フィードバック経路 | **✅ 検証済み(2026-11-06)**。アラート詳細の「⚠ 誤検知として報告」→ `fall_threshold` が 0.77→0.79 に上がり、状況が「誤検知」に。**テストで上げた分は 0.77 に戻済み** |
| 4 | 無動作検知の感度 | `STILLNESS_MOVE_THRESHOLD = 0.004`(`ai_engine.py`)が実環境に合うか。無動作テスト(上記#1)と合わせて確認が必要 |
| 5 | 複数カメラ | このマシンは1台のみのため未検証 |
| 6 | `Recording`(自動録画)は**作成しない**仕様のまま | 要望があれば実装(実録画ファイルの保存先・コーデックの選定が必要) |

---

## 3. 現状の設定(DB・settings.py)(2026-11-06 時点)

| 項目 | 現状 | 備考 |
|---|---|---|
| `AISettings.enabled` | **True(AI監視 稼働中)** | 2026-11-06 に True へ戻済み |
| `core_alert` | 1件(#245、**誤検知扱い**) | デモデータが必要なら `python manage.py seed_demo` |
| `fall_threshold` | **0.77** | フィードバックテストで一時 0.79 になったが 0.77 に戻済み |
| `AI_SIMULATOR_ENABLED` | **False(変更済み)** | デモ通知は**停止**。実AIの解析結果だけが通知される。デモ通知が必要なら `config/settings.py` を `True` に戻す |
| `AI_REALTIME_ENABLED` | **True** | False→True の切替検証を実施し戻済み |

---

## 4. 再開手順

```powershell
# 1) サーバー起動
cd C:\Users\student\code\ai2
.venv\Scripts\Activate.ps1
python manage.py runserver 127.0.0.1:8000

# 2) ブラウザで http://127.0.0.1:8000/ を開く
#    ログイン: staff1 / demo1234  (他: staff2/demo1234, admin/admin1234)

# 3) 左メニュー「カメラデバッグ」→ デバイス(index 0)を選択 →「表示開始」
#    → 骨格・判定overlay付き映像 + AIステータスが流れる

# 4) 動作確認の自動検証
python manage.py check
python manage.py verify_pages
```

**確認ポイント**: AIステータスの `解析○fps`(10前後) / `状態` / `判定` / `危険度` /
`無動作 N/30秒`。異常が飛んだら「異常検知」メニューから対応→解決→報告の流れ。

### 2026-11-06 の再開作業で消化したもの
- `AISettings.enabled` を **True** に復旧(設定反映を確認)
- `AI_SIMULATOR_ENABLED = False` に変更し、**デモ通知停止・実AI通知のみ**を確認(ログにシミュレーター停止メッセージ)
- 無動作(30秒静止)テストは**スキップ**(ユーザー判断、未検証のまま)
- 誤検知フィードバック経路・`AI_REALTIME_ENABLED` 切替の実機検証(上記#3 / #2)
- `/debug/camera/` で 9.6〜9.7fps の解析・overlay配信を再確認
- `manage.py check` / `verify_pages` 全通過

### 次にやること(優先順)
1. **(任意)無動作検知の30秒静止テスト**(唯一残った動作未検証項目)
2. (任意)本メモの「2. 未完了」の#4・#5を消化

---

## 5. 2026-11-06 追加工事(常時稼働・自動録画・検知進行バー)

### (1) クールダウン短縮
- `AISettings.cooldown_seconds` を **300 → 10秒** に変更済み(通知がすぐ来るように)
- 通知の届くまでの遅延は **ブラウザの `/api/alerts/` ポーリング5秒間隔**(`static/js/app.js`)が残る

### (2) リアルタイムAIの常時稼働(`AI_ALWAYS_ON`)
- `/debug/camera/` を開いていない時・映像を「停止」した後も、**サーバー側で解析・異常検知・録画が走り続ける**
- 実装:`core/apps.py` が **runserverのワーカープロセスでのみ** `ai_engine.start_persistent()` を遅延起動
  (`--noreload`時は単一プロセス、autoreload時は `RUN_MAIN=true` の子だけ。migrate/test 等では起動しない)
- `camera_service.acquire()` でエンジンがカメラを常時確保(参照カウントなのでブラウザの「停止」でも解放されない)
- `detach()` は視聴者0でも `_persistent` 中なら解析を止めない
- 別デバイスへ「表示開始」すると常時稼働もそのデバイスへ追従する
- 状態APIに `persistent`、画面に「常時解析中 ○○fps」表示を追加
- 設定で止める場合:`AI_ALWAYS_ON = False` / 対象カメラは `AI_ALWAYS_DEVICES`(既定None=全カメラ)

### (3) 異常検知からの自動録画(8秒)
- **検知した時点から `AI_RECORDING_SECONDS`(既定8秒)間**のoverlay付きフレームを蓄積し、
  mp4(H.264)+ JPEGサムネイルを `media/recordings/ai_<kind>_<日時>_cam<id>.mp4` へ保存、`Recording` を作成
- 既存の「異常検知一覧/詳細の 🎞 録画を再生」リンク、`/recordings/` 一覧がそのまま使える
- 書き出しは別スレッド(`ai-recording-writer`)。失敗しても解析は止めない
- **依存に `imageio-ffmpeg` を追加**(ffmpegバイナリ同梱 / `requirements*.txt` 記載済み・導入済み)
- `MEDIA_ROOT = BASE_DIR/"media"`、`MEDIA_URL="/media/"` を追加し、`DEBUG` 時のみ `urls.py` で配信
- 合成JPEGによる書き出し検証済み(実カメラ不要で mp4+サムネイル+Recording 作成/削除 OK)

### (4) デバイス検知の進行バー
- `/debug/camera/progress/` を新設(`camera_service.detect_devices` が index確認/デバイス名取得の進捗を記録)
- `debug_camera.js` が400msポーリング、`templates/debug/camera.html` にバーUI、CSSは `.detect-progress*`

### 検証済み(persistent確認済)
- `/debug/camera/ai/` が `phase=running / persistent=true / fps=9.7`(画面を開いていない状態でも継続)

### 未検証
- 実際の転倒検知→自動録画mp4の再生(8秒録画の実環境確認 / 検知を人为起こす必要あり)
- 無動作30秒検知(前掲のとおりスキップ中)

---

## 6. 2026-11-06 カメラ検知「2台あるのに1台しか出ない」の解決

### 原因(実測)
| 方法 | index 0(Logi C270) | index 1(Web Camera - HD) |
|---|---|---|
| MSMF(旧実装の既定) | 0.7秒 映像OK | **54秒ハング**→ read失敗 → 「無し」扱いで一覧から消えていた |
| DSHOW | 0.7秒 映像OK | **0.4秒** 映像OK |

- 旧実装は MSMF 1回だけ / read失敗したら即「無し」
- `CAP_PROP_OPEN_TIMEOUT_MSEC`・`CAP_PROP_READ_TIMEOUT_MSEC` は **MSMF に効かない**(60秒ハング)
- バックエンドごとにインデックスの割当順が違う

### 対策(`core/camera_service.py`)
1. `_backends()` を **DSHOW → MSMF** の順に(速い方优先。DSHOW が見えないカメラだけ MSMF)
2. `_open_capture()` がバックエンドを総当たり。開けるが映像が無い場合は `available=False` で返す
3. `_probe()` / `acquire()` も同じ方式(acquire は DSHOW 優先で開く)
4. **検知の非同期化**: `detect_devices()` は検知スレッドを起こして即 `{"ok":true,"pending":true,"devices":部分結果}` を返す
   (`_run_detection` / `_detect_partial`。キャッシュは完了時に確定)
5. `detect_progress()` が `devices`(部分結果)も返す
6. 結果: **検知 63秒/1台 → 3.1秒/2台**(index 0 = Logi C270 HD WebCam / index 1 = Web Camera - HD)

### 画面(`static/js/debug_camera.js` / `templates/debug/camera.html`)
- pending の間は進行バーと「検知中ですでに分かったカメラを表示しています…」を出し続ける
- 部分結果を随時一覧に反映(1台目が重くても2台目を先に選べる)
- `available === false` のデバイスは取り消し線+「開けるが映像なし(他アプリ使用中の可能性)」。クリック不可
- 進行バーの段階にバックエンド名を表示(例 `カメラ index 1 を確認中…(DSHOW)(3/9) / 1.2秒`)
- デバッグページの JS は `?v=<timestamp>` でキャッシュ無効化

### 追加コマンド
`python manage.py list_cameras [--shots] [--max N]`
OS列挙(PnP)+バックエンド×インデックスの総当たり結果+実際に写った画像を `media/camtest/` に保存。
次回「1台しか出ない」が出たときにまずこれで切り分ける。

### AI常時稼働との関係
- 常時稼働は **検知できた全カメラ** を同時に解析する(`AI_ALWAYS_DEVICES` で明示指定も可)
- `/debug/camera/` の「表示開始」は**そのカメラを見るだけ**。見始めなくても・「停止」してもAIは走り続ける
- ただしこのPCのUSB帯域の制約で、2台同時だと後から開いた側が 0〜1fps になる(→ 第9章)

---

## 7. 2026-11-06 「USBカメラがまだ認識しない」の解決

### 真の原因
AI常時稼働が1台を占有していると、**もう1台を開こうとして約60秒ハングして失敗**する(Windows実測)。
旧実装はこれを「カメラは存在しない」と扱っていたため、一覧から消えていた。
(サーバー停止時は DSHOW で2台とも0.4〜0.7秒で映像OK。index 0=Logi C270 / index 1=Web Camera - HD を実画像で確認)

### 対策
| # | 内容 | 実装 |
|---|---|---|
| 1 | 1インデックス6秒の時間予算(ハングを待たない) | `camera_service._probe_with_budget()` |
| 2 | OpenCV で開けなくても **OS列挙(PnP)にあれば一覧に出す** | `_os_camera_names()` + `busy: true` デバイス |
| 3 | busy デバイスは**選択可能**(警告色・破線)。選べばAIが切り替わる | `debug_camera.js` / `.debug-device.is-busy` |
| 4 | 切り替え時に占有を解放してから開く | ~~`ai_engine.prepare_for(device)`~~ **第9章で廃止(全カメラ同時解析へ)** |
| 5 | 「表示開始」したカメラが常時稼働の対象として維持される | `start_persistent(index)` を同 view で呼ぶ |
| 6 | 使用中カメラにもOS名前を付ける | `_run_detection` の名前付与 |

### 検証済み(サーバー稼働中 = index 0 を常時稼働が占有した状態)
- 検知結果: `index 0 / カメラ名 / 480×640 / DSHOW / 配信中` + `index 1 / Web Camera - HD / 使用中のため映像を確認できません(選択するとAIがこのカメラへ切り替わります)` → **2台とも一覧に出る**
- index 1 を選択して「表示開始」→ **配信中 / 常時解析中 9.7fps / device=1 / persistent=true / 640×480 配信**
- `manage.py check` / `verify_pages` 全通過

### 残る注意
- ~~常時稼働の初期対象は `AI_ALWAYS_DEVICE_INDEX`(既定 0)~~ → **第9章で全カメラ同時解析に変更済み**
- 2台同時のfpsはUSB帯域で頭打ち(このPC実測: 30fps + 1fps)

---

## 8. 2026-11-06 「Webアプリにアクセスできなくなった」の解決

### 症状
`/debug/camera/` でAIが動き出した直後から、全ページが接続中断で開けなくなった。

### 原因(2つ重なっていた)
1. **runserver の二重起動**(11:09起動と11:21起動)。Windowsは `SO_REUSEADDR` で
   同じポート8000を両方がbindできてしまい、**両者のAI常時稼働がカメラを奪い合って
   互いに約60秒ハング**。`py-spy dump` ではHTTPスレッドがselectで待ち受け中に
   クライアント側がRSTを受ける状態だった。
2. **解析スレッドがGILを握り続けていた**。`py-spy` のホットスタックが
   `_draw_japanese → PIL Image.fromarray` を指していた。日本語overlayを
   **1フレーム5回(行ごとに)BGR→RGB→PIL→BGR**変換しており、これが全スレッドを飜わせていた。

### 対策
| # | 内容 | 実装 |
|---|---|---|
| 1 | overlay描画を**1フレーム1回のPIL往復**に統合。縁取りは9回ループ→`stroke_width` | `ai_engine._draw_japanese_overlay()` |
| 2 | **見る人がいない時は描画とJPEG化を省略**(検知は継続)。常時稼働の自己視聴は視聴者に数えない | `_has_browser_viewer()` / ループの `draw` フラグ |
| 3 | **runserver二重起動のガード**。先取したPIDだけが常時稼働を開始 | `core/apps.py` の `.ai_always_on.lock`(atexitで解放) |
| 4 | `acquire()` は**カメラ開きをロック外**で実行(ハングが他要求を巻き込まない) | `camera_service.acquire()` |
| 5 | 運用: 古いツリーを停止(ユーザー承認済) | — |

### カメラ未接続について(正常な状態)
USBカメラを外した状態でもアプリは正常。
- 検知は空一覧を即返す(`カメラデバイスが検知されませんでした` を表示)
- 常時稼働は開始を諦めて待機し、`AI_ALWAYS_RETRY_SECONDS`(既定30秒)毎に再試行
  → 接続されれば自動で始まる。失敗ログは初回のみで連発しない
- 実測: 内蔵カメラ1台のみで `検知 87ms` / `常時解析中 9.7fps` / HTTP 8〜20ms

### 検証結果(2026-11-06 再検証・実測)
- HTTP: 連続リクエスト **47〜66ms**(視聴者あり=描画ON時)/ 並列8本でも最大300ms。対策前は接続中断
- `py-spy`: `realtime-ai` スレッドは `active+gil`(PIL張り付き) → **idle**(レート制限の待ち受け)
- デバイス検知: **2台とも一覧に出る**(`index 0 Logi C270 HD WebCam / DSHOW` + `index 1 Web Camera - HD`)
- カメラ切り替え: index 1 を選んで「表示開始」→ **device=1 / persistent=true / 9.7fps**へ移行
- 「停止」後もAI継続(**停止中 / 9.8fps / persistent=true**)→ 再開始もOK(キャプチャリークなし)
- **検知→録画→再生 E2E**: 閾値を一時的に0.05へ下げて転倒を検知させ、
  `Recording` が `mp4 290KB / 640×480 / 7.8秒` + サムネイル + マーカー付きで生成、
  `/media/...mp4` は `200 / video/mp4` で配信、ブラウザの `<video>` で **再生確認済み**
  (異常検知一覧の「🎞 検知瞬間の録画を再生」→ 詳細ページも動作)
  → テストで出たアラート/録画/ファイルは削除し、閾値0.77・クールダウン10秒へ復元済み
- `manage.py check` / `verify_pages` 全通過

---

## 9. 2026-11-06 本番挙動へ(全カメラ同時解析・AIは常時稼働)

ユーザー指摘: **「本番はすべてのカメラを動かし、debugカメラでその様子を見れる機能であり、AI認識モデルは常に動いているのが正しい挙動」**
→ 以前の「1エンジン=1カメラ、見たいカメラへ切り替える」設計を廃止し、**カメラごとにスレッド**へ作り直した。

### `core/ai_engine.py` を再構築
| クラス | 役割 |
|---|---|
| `_CameraRuntime` | **1カメラ分**の解析スレッド・視聴者数・最新JPEG・状態・録画状態 |
| `RealtimeAIEngine` | device → `_CameraRuntime` の辞書を管理するシングルトン(attach/detach/status/start_persistent…) |
| `_load_shared()` / `_get_landmarker(device)` | Kerasモデルは**全カメラ共有**(推論は `infer_lock` で直列化、約7ms)。MediaPipeはスレッドセーフでないため**カメラ毎に1個**生成してキャッシュ |

- `attach(device)` / `detach(device, session)` / `latest_jpeg(device)` — すべて device 引数付き
- `status(device=None)` — `?device=N` でそのカメラ、無しは**一番稼働しているカメラ** + `devices`(全カメラ要約)
- `summary()` — 全カメラの phase/fps/状態/視聴者/エラー一覧(存在しないindexの幽霊項目は出さない)
- `target_devices()` — `AI_ALWAYS_DEVICES` 指定が無ければ**検知できた全カメラ**、**index降順**に開く
- `prepare_for()` は削除(切り替え方式の廃止)

### 常時稼働(`core/apps.py`)
- runserver起動 → 2秒後 → **全カメラの常時稼働を開始**、以後 `AI_ALWAYS_RETRY_SECONDS`(30秒)毎に再スキャン
  → **後から差し込まれたカメラも自動で解析に加わる**(未接続でもアプリは正常)
- `.ai_always_on.lock`(PID)でサーバー二重起動時のカメラ争奪を防止

### 映像を渡さないカメラの見張り(`_monitor_loop`)
`cap.read()` が長時間ブロックするとループ内のタイムアウトが発火しないため、**別スレッド**で監視し、
`AI_FRAME_LOST_SECONDS`(20秒)間フレームが無かったカメラは
解析を停止 + キャプチャを解放(他のカメラへ帯域を返す)+ `AI_STARVED_RETRY_SECONDS`(300秒)は再試行を抑止。

### 実測で分かったハードウェア制約(重要)
このPCで2台を同時に開くと **先に開いたカメラがUSB帯域を独占**し、後から開いた側は 0〜1fps
(320×240に落としても、バックエンドを分けても改善せず)。

| 開放順 | 結果 |
|---|---|
| index 0 → 1 | 1台目30fps / **2台目は開けないか1fps** |
| index 1 → 0 | **両方開く**(1台目30fps / 2台目1fps) |

→ ソフト側対策は「**index降順に全カメラを開く**」+「**飢えたカメラは見張りが解放**」。
安定して2台以上を同時解析するには **カメラを別のUSBコントローラに分散接続** する必要がある
(ハブに纏めない)。

### 検証結果(2026-11-06)
- 起動ログ: `[RealtimeAI] 常時稼働を開始しました: index 1` / `index 0` / `解析中のカメラ: index [0, 1]`
- 実行A: **2台同時解析**(`index 0 = 1fps`, `index 1 = 9.7fps` / ともに persistent=true)
- 実行B: index 0 が1コマも取れず → 見張りが停止(`index 0 停止 / 映像が取得できないため…`)、
  **index 1 は 9.7fps を維持**(帯域が戻った)
- デバッグページ: 「全カメラの稼働状況」一覧 + 停止理由の注記、ライブ表示が「停止中」でもAIは稼働
- `manage.py check` / `verify_pages` 全通過

---

## 10. 2026-11-09 requirements.txt / requirements-windows.txt の同期チェック

### やったこと
1. 2ファイルのピンを機械比較
2. アプリ全ソースをASTで走査し、importされているサードパーティが両ファイルに有るか確認
3. **`pip install --dry-run --only-binary=:all: --platform … --python-version …`** で
   Linux/Windowsそれぞれの環境で実際に解決できるか検証(PyPI解決試験)
4. 実venv(`pip freeze`)とピン表的

### 結果
| 項目 | 結果 |
|---|---|
| 2ファイルの内容差 | 共有9パッケージは**バージョン完全一致**。Linuxのみ `gunicorn`(意図どおり) |
| アプリimport網羅 | `django / cv2 / PIL / numpy / tensorflow / mediapipe / imageio_ffmpeg` すべて記載済(`numpy`は推移依存) |
| ⚠️ **見つかった不具合** | `requirements.txt` の `tensorflow==2.21.0` は **Linux用wheelが存在せずインストール不能**(Linuxの最新は2.20.0)。Windowsは2.21.0でOK |
| 其它のピン | `mediapipe==0.10.32` / `pillow==12.3.0` / `imageio-ffmpeg==0.8.1` / `opencv-contrib-python==5.0.0.93` は Linux py3.12/3.13 で解決OK |

### 対応(ユーザー選択: Linuxだけ2.20.0 / 現環境維持)
- `requirements.txt`: **`tensorflow==2.20.0`** に修正 + 理由をコメント化
- `requirements-windows.txt`: `tensorflow==2.21.0` のまま(実venvと一致)+ Linuxとの差分をコメント化
- 両ファイルに **py-spy は開発venv専用の調査ツール(本番不要)** を明記(導入自体はそのまま維持)
- README に同期状態の表を追記

### 修正後の検証
- Linux manylinux_2_28/2_17/2014 × py3.13 → 解決OK
- Linux × py3.12 → 解決OK
- Windows win_amd64 × cp313 → 解決OK
- 実venv vs `requirements-windows.txt` → **9/9 完全一致**
- 実venv vs `requirements.txt` → tensorflowのみ意図的差分(2.21.0 vs 2.20.0)、gunicornはWindows不要

---

## 11. 2026-11-09 追加学習(再学習)パイプラインを ai2 に移植

ユーザー指摘: 「`caregiver_safety/data` に追加学習の材料があったが実装したか。ai2 に入っていない」
→ **当時は推論用モデル4ファイルだけをコピーし、材料・学習スクリプトは未移植だった**ので移植した。

### 取り込んだ材料(ai2内)
| 場所 | 中身 |
|---|---|
| `train_data/` | 姿勢CSV **39個**(`fall_*` 13 / `normal_*` 26、23.2MB)。99値+ラベル+人物番号 |
| `train_dataset/` | 学習テンソル(X/y, state_X/state_y, state_labels)。元ファイルは `_caregiver_original/` に退避 |
| `ai_models/candidates/` `ai_models/backup/` | 学習候補 / 反映前の旧モデルの退避先 |

### 追加したコード
- `core/training.py` … 共通処理(パス・CSV読込・シーケンス生成・状態ラベル対応表 `STATE_BY_SUFFIX`・backup/promote)
- `core/management/commands/ai_collect_data.py` … カメラ→MediaPipe Pose→CSV収集(`--device --backend --label --name --seconds --no-gui`)
- `ai_prepare_dataset.py` / `ai_prepare_state_dataset.py` … CSV→.npy(`--dry-run` `--list-unmapped`)
- `ai_train_fall.py` / `ai_train_state.py` … LSTM再学習(`--epochs --batch-size --promote`)
  - **既定は `candidates/` へ出すので現行モデルは壊れない**。`--promote` で旧モデルを backup してから反映
  - 状態モデルは `state_labels.npy` も**セットで**反映(出力次元とラベル順の一致を守る)
- `ai_check_model.py` … 検証(精度/混同行列/CSV別誤判定。**既定で AI設定の転倒閾値で評価**、`--path` で候補も検証可)
- `settings.py`: `AI_TRAIN_DATA_DIR` / `AI_TRAIN_DATASET_DIR` を追加
- 依存に **pandas==3.1.1 / scikit-learn==1.9.1** を両requirementsへ追加(Linux/Windows cp313で解決確認済)

### 元スクリプトからの改善点
- `load_csv_features` が**先頭行が数値なら `header=None` で読む**
  (元の `prepare_dataset.py` は先頭行をヘッダ扱いして1フレーム失っていた)
  → その結果 転倒データは 2,278 → **2,288** シーケンス(状態は 301 のまま一致)
- 壊れたCSVがあっても全体を止めず `[SKIP]` 理由を列挙
- 学習 → 検証 → 反映 の順を強制(candidates + `--promote`)

### 検証結果(実測)
```
ai_prepare_dataset        : X (2288,30,99) NORMAL 1912 / FALL 376(16.4%)
ai_prepare_state_dataset  : state_X (301,30,99) 8クラス内訳OK
ai_check_model(現行, 閾値0.77): 正解率 96.68% / 誤検知率 0.26%(5件) / 見逃し率 18.88%(71件)
ai_train_fall --epochs 3  : 候補生成OK(検証Acc 86.9% / 0.77閾値 86.68%)→ 候補は廃棄
ai_train_state --epochs 2 : クラス重み計算・候補生成OK → 候補は廃棄
ai_check_model --path candidates/... : 候補検証OK
manage.py check / verify_pages : 全通過
```
- 現行モデル(`ai_models/*.keras`)は無変更(テスト候補は削除済み)

### 運用メモ
- **見逃し(FALL→NORMAL)18.9%が課題**。`fall_歩行中に転倒…` 系CSVで誤判定59〜91%
  → `ai_collect_data --label fall` で該当動作を追加収集 → 再学習が効く
- `ai_collect_data` は **runserverを止めてから**実行(AI常時稼働がカメラを掴むため)
- `--promote` 後は **サーバー再起動が必要**(モデルは初回使用時にキャッシュされる)

---

## 12. 2026-11-09 再学習をサーバー起動時の自動化

ユーザー指摘: 「やることは同じだし、コマンドというより DjangoでServer建てる時自動化してほしい」
→ 手動コマンドベースを **起動時自動**へ変更(`core/retraining.py`)。

### 仕組み
- `train_data/*.csv` の**指紋**(ファイル名+サイズ+mtime の sha256先頭16桁)を
  `train_dataset/retrain_state.json` と比較して **変わった時だけ**学習する
  - 変わらなければ数秒で素通り → **autoreload の再起動を繰り返しても無駄に学習しない**
- 変わった時: データセット再生成 → 候補を `ai_models/candidates/` へ学習 →
  **同じ保持データで現行モデルと比較** → 劣がなければ `ai_models/` へ反映(旧版は `ai_models/backup/<日時>/`) → 指紋記録
- 反映判定は AI設定の転倒閾値での **正解率 / 誤検知率 / 見逃し率** の3指標
  (`AI_RETRAIN_PROMOTE_MARGIN` 以内的劣化は許容)。劣る場合は**見送って候補だけ残す**
- 学習失敗時は現行モデルをそのまま使い、Webアプリと解析は止めない
- 呼び出しは `core/apps.py` の起動スレッド内、**常時稼働を開始する前**
  (学習がCPUを奪って解析と争うのを避ける。ロック取得後のため二重起動でも1プロセスしか学習しない)

### 追加/変更したファイル
| ファイル | 内容 |
|---|---|
| `core/retraining.py` | 新規。`needs_retrain()` / `run_startup_retraining()` / `last_run_summary()` |
| `core/training.py` | モデル定義・学習・評価を共通化(`build_*_model` / `train_fall` / `train_state` / `evaluate_fall_at_threshold` / `data_fingerprint` / `read_state` / `write_state`) |
| `core/management/commands/ai_retrain.py` | 新規。`--status` / `--force`(手動実行・確認用) |
| `ai_train_fall.py` / `ai_train_state.py` | 共通関数を使うよう整理(モデル定義の重複を排除) |
| `core/apps.py` | 起動時に自動再学習 → その後 常時稼働開始 |
| `core/views.py` | `/debug/camera/ai/` に `retrain`(最新実行情報)を追加 |
| `templates/debug/camera.html` `static/js/debug_camera.js` `static/css/style.css` | AIカード下に「自動再学習 最終: …」を表示 |
| `config/settings.py` | `AI_AUTO_RETRAIN` / `AI_RETRAIN_EPOCHS_FALL` / `AI_RETRAIN_EPOCHS_STATE` / `AI_RETRAIN_PROMOTE_MARGIN` |

### 検証結果(実測)
- `ai_retrain --status`: 指紋 `73d834dcedc96b35` / 39ファイル / 実行必要=はい(記録なし)
- **ガード検証**(`AI_RETRAIN_EPOCHS_*` を一時2にして `ai_retrain --force`):
  - 転倒: 現行 acc 96.94%・見逃し17.33% vs 候補 acc 88.43%・見逃し69.33% → **反映見送り**
  - 状態: 現行 72.13% vs 候補 14.75% → **反映見送り**
  - `ai_models/*.keras` のMD5は実行前後で**同一**(現行維持)、`backup/` は空、候補のみ生成、14.5秒
  - → テスト候補は削除、エポックは50へ復元
- 2回目以降: `[Retrain] データ変更なし(39ファイル)` で素通り
- runserver 起動ログ: `[Retrain] データ変更なし…` → 常時稼働開始 → `/debug/camera/` は 9.8fps
- UI表示: 「自動再学習 最終: 2026-11-09 11:00:58 / 材料 39件 / 転倒モデルは現行維持 / 状態モデルは現行維持 / 14.5秒」
- `manage.py check` / `verify_pages` 全通過
- 実運用で転倒検知→通知バナー(未対応4件)を確認

### 運用
- **材料を増やす操作だけユーザーが実施**: `python manage.py ai_collect_data`(またはCSVを `train_data/` に置く)
- 次回 `runserver` 起動時に自動で 前処理→学習→比較→反映
- 即時反映したい / 状況を見たいときだけ `python manage.py ai_retrain`(または `--status` / `--force`)
