"""CARE SEC 転倒・異常検知システム / 実カメラキャプチャサービス(デバッグページ用)

サーバー起動マシンに接続されたカメラをOpenCVで開き、
ブラウザへMJPEGストリームとして配信するためのテスト機能。
デモ用データ(core.models.Camera 等)とは完全に独立しており、
今後ここに新しいAI認識モデルを接続していく予定。

OpenCVが未導入でもアプリ自体は起動できるよう、cv2のimportは遅延させる。
"""
import glob
import platform
import subprocess
import threading
import time

from django.conf import settings

_cv2 = None
_cv2_error = ""

# 検知結果のキャッシュ / 配信中ストリーム(index単位)
_detect_cache = {"at": 0.0, "devices": None}
_detect_lock = threading.Lock()
_detect_thread = None      # 検知はバックグラウンドスレッドで実行(HTTPをブロックしない)
_detect_partial = []       # 検知中に見つかったデバイス(部分結果)
_streams = {}
_streams_lock = threading.Lock()

# デバイス検知の進捗(ブラウザの進行バー表示用)
# state: idle / running / done / error
_detect_progress = {
    "state": "idle",
    "stage": "",
    "current": 0,
    "total": 0,
    "started_at": None,
    "finished_at": None,
}
_detect_progress_lock = threading.Lock()


def _load_cv2():
    """cv2を一度だけimportする(未導入時はエラー文字列を返す)"""
    global _cv2, _cv2_error
    if _cv2 is None and not _cv2_error:
        try:
            import cv2  # OpenCVをオプション依存にするため遅延import
            _cv2 = cv2
        except Exception as exc:  # 環境依存(opencv-python-headless 未導入など)
            _cv2_error = f"{type(exc).__name__}: {exc}"
    return _cv2, _cv2_error


def _max_devices():
    return int(getattr(settings, "DEBUG_CAMERA_MAX_DEVICES", 4))


def _set_progress(**kwargs):
    """進捗情報を更新する(detect_devices の実行中だけ呼ばれる)"""
    with _detect_progress_lock:
        _detect_progress.update(kwargs)


def detect_progress():
    """デバイス検知の進捗を返す(ブラウザの進行バー用)

    検知中でも既に見つかったデバイス(`devices`)を返すので、
    1台目の確認に時間がかかっていても2台目以降を先に選べる。
    """
    with _detect_progress_lock:
        data = dict(_detect_progress)
    if data["state"] == "running" and data["started_at"] is not None:
        data["elapsed"] = round(time.monotonic() - data["started_at"], 1)
    else:
        data["elapsed"] = None
    data["devices"] = list(_detect_partial)
    return data


def _cache_seconds():
    return float(getattr(settings, "DEBUG_CAMERA_CACHE_SECONDS", 30))


def _friendly_names_windows(count):
    """Windows: PnPのカメラ一覧(FriendlyName)を列挙順で返す(ベストエフォート)"""
    return _os_camera_names()[:count]


def _os_camera_names():
    """OSが認識しているカメラ名を列挙順に返す

    OpenCV はカメラを開けなければ存在を検知できないが、他カメラの使用中は
    開こうとしてもハングする(実測 約60秒)ため、OS列挙側でも名前を取って
    「存在するが映像を確認できない」カメラを一覧に出す。
    """
    try:
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "Get-PnpDevice -Class Camera, Image -PresentOnly -ErrorAction SilentlyContinue | "
             "Select-Object -ExpandProperty FriendlyName"],
            capture_output=True, text=True, timeout=5,
        )
    except Exception:
        return []
    return [line.strip() for line in proc.stdout.splitlines() if line.strip()]


def _friendly_names_linux():
    """Linux: /sys/class/video4linux/videoN/name からインデックス対応の名前を返す"""
    names = {}
    for path in sorted(glob.glob("/sys/class/video4linux/video*")):
        suffix = path.rsplit("video", 1)[-1]
        if not suffix.isdigit():
            continue
        try:
            with open(f"{path}/name", encoding="utf-8", errors="replace") as fh:
                names[int(suffix)] = fh.read().strip()
        except OSError:
            continue
    return names


def _capture_info(cap, index, backend_name=None):
    """開いたキャプチャから解像度等の情報を取り出す"""
    height, width = cap.get(3), cap.get(4)  # CAP_PROP_FRAME_WIDTH / HEIGHT
    fps = cap.get(5)  # CAP_PROP_FPS(取得できない backend では負値になる)
    return {
        "index": index,
        "name": f"カメラ {index}",
        "width": int(width) if width else None,
        "height": int(height) if height else None,
        "fps": round(float(fps), 1) if fps and fps > 0 else None,
        "backend": backend_name or cap.getBackendName(),
    }


def _open_params(cv2):
    """開き/読みのタイムアウト(ms)

    OpenCV の既定値は非常に長く、使えないインデックスで数十秒ハングする
    (実測で MSMF index 1 が62秒)。打ち切って検知を続けられるようにする。
    ※ MSMF はこの指定を無視することがあるため、バックエンド順(DSHOW優先)で対策する。
    """
    if platform.system() != "Windows":
        return []
    open_ms = int(getattr(cv2, "CAP_PROP_OPEN_TIMEOUT_MSEC", -1))
    read_ms = int(getattr(cv2, "CAP_PROP_READ_TIMEOUT_MSEC", -1))
    if open_ms < 0 or read_ms < 0:
        return []
    return [open_ms, 2500, read_ms, 1500]


def _backends(cv2):
    """試すバックエンド(Windowsは DSHOW / MSMF の順)

    インデックスの割当順はバックエンドごとに異なるため両方必要だが、
    実測で **DSHOW の方が圧倒的に速い**(同じカメラが MSMF では最初の1フレームに
    約54秒、DSHOW では0.4秒)。タイムアウト指定も MSMF に効かないため、
    速い DSHOW を先に試し、DSHOW が見えないカメラだけ MSMF で拾う。
    """
    if platform.system() == "Windows":
        return [("DSHOW", cv2.CAP_DSHOW), ("MSMF", cv2.CAP_MSMF)]
    return [("既定", cv2.CAP_ANY)]


def _open_capture(cv2, index):
    """インデックスを順に開き、フレームを読めた (cap, backend名, frame) を返す

    どれでも読めなければ (None, None, None)。
    「開けるが映像が無い」場合は (None, None, "blocked") を返す。
    """
    params = _open_params(cv2)
    blocked = False
    for backend_name, backend in _backends(cv2):
        try:
            cap = cv2.VideoCapture(index, backend, params) if params else cv2.VideoCapture(index, backend)
        except Exception:  # noqa: BLE001 -パラメータ非対応の環境では素で開く
            cap = cv2.VideoCapture(index, backend)
        if not cap.isOpened():
            cap.release()
            continue
        frame = None
        for _ in range(3):  # 初回readは暖気で失敗することがある
            ok, frame = cap.read()
            if ok and frame is not None:
                return cap, backend_name, frame
            time.sleep(0.2)
        cap.release()
        blocked = True  # 開けたが映像が無い
    return None, None, "blocked" if blocked else None


def _probe(index, cv2):
    """インデックスを開いて1フレーム読めるバックエンドを探す

    開けるが映像が無いカメラも `available=False` で返す(一覧には出す)。
    何も開けられなければ None。
    """
    cap, backend_name, frame = _open_capture(cv2, index)
    try:
        if cap is not None:
            return _capture_info(cap, index, backend_name)
    finally:
        if cap is not None:
            cap.release()
    if frame == "blocked":
        return {"index": index, "name": f"カメラ {index}", "available": False}
    return None


def _probe_with_budget(index, cv2, budget=6.0):
    """`_probe` を時間予算つきで実行する

    他カメラが使用中だと Windows では開くこと自体が約60秒ハングする。
    検知を止めないため、予算を過ぎたら待つのをやめる(裏のスレッドは
    開けたら自分で解放する)。戻り値は probe の結果か、"timeout"。
    """
    box = {}

    def work():
        try:
            box["value"] = _probe(index, cv2)
        except Exception as exc:  # noqa: BLE001 -検知は続けたい
            box["value"] = None
            box["error"] = f"{type(exc).__name__}: {exc}"

    thread = threading.Thread(target=work, name=f"camera-probe-{index}", daemon=True)
    thread.start()
    thread.join(budget)
    if thread.is_alive():
        return "timeout"
    return box.get("value")


def detect_devices(force=False):
    """カメラデバイス検知を開始し、結果を待たずに返す(非同期)

    - 見つかったデバイスはキャッシュされる
    - 検知中は `{"ok": True, "pending": True, "devices": 部分結果}` を返す
    - 進捗と部分結果は `detect_progress()` からも取れる

    MSMF は使えないインデックスで約60秒ハングすることが実測されたため
    (CAP_PROP_OPEN/READ_TIMEOUT_MSEC も効かない)、HTTPリクエストをブロックせず、
    見つかった分だけ先に一覧へ出せるようにする。
    """
    global _detect_thread, _detect_partial

    cv2, error = _load_cv2()
    if cv2 is None:
        _set_progress(
            state="error",
            stage="OpenCVを利用できません",
            current=0,
            total=0,
            finished_at=time.monotonic(),
        )
        return {
            "ok": False,
            "error": f"OpenCV(opencv-python-headless)を利用できません: {error}",
            "devices": [],
        }

    with _detect_lock:
        now = time.monotonic()
        cached = _detect_cache["devices"]
        if not force and cached is not None and now - _detect_cache["at"] < _cache_seconds():
            _set_progress(state="done", stage="キャッシュ済み", finished_at=now)
            return {"ok": True, "cached": True, "devices": cached}

        if _detect_thread is not None and _detect_thread.is_alive():
            # すでに検知中 → 進捗だけ返す
            return {"ok": True, "pending": True, "devices": list(_detect_partial)}

        _detect_partial = []
        _detect_thread = threading.Thread(
            target=_run_detection,
            args=(cv2,),
            name="camera-detect",
            daemon=True,
        )
        _detect_thread.start()
        return {"ok": True, "pending": True, "devices": []}


def _run_detection(cv2):
    """検知本体(バックグラウンドスレッド)"""
    global _detect_partial

    max_devices = _max_devices()
    started = time.monotonic()
    total = max_devices + 1  # +1 = OS列挙(デバイス名)ステップ
    _set_progress(
        state="running",
        stage="カメラを確認しています…",
        current=0,
        total=total,
        started_at=started,
        finished_at=None,
    )

    # OSが認識しているカメラ名を先に取る(開けなくても「存在する」ことを示すため)
    if platform.system() == "Windows":
        os_names = _os_camera_names()
    else:
        linux_names = _friendly_names_linux()
        os_names = [linux_names.get(i, "") for i in range(max_devices)]

    devices = []
    for index in range(max_devices):
        _set_progress(
            stage=f"カメラ index {index} を確認中…",
            current=index,
        )
        with _streams_lock:
            active = _streams.get(index)
        if active:
            # 配信中のデバイスは開き直せず検知できないため、配信中として報告する
            devices.append(dict(active["info"], in_use=True))
            _detect_partial = list(devices)
            continue

        info = _probe_with_budget(index, cv2)
        if info == "timeout":
            # 開こうとしてハング(他カメラ使用中に多い)。OS列挙にあれば一覧には出す
            if index < len(os_names):
                devices.append({
                    "index": index,
                    "name": os_names[index] or f"カメラ {index}",
                    "available": False,
                    "busy": True,
                })
        elif info:
            devices.append(info)
        elif index < len(os_names):
            # OpenCV では開けないが OS には存在するカメラ
            devices.append({
                "index": index,
                "name": os_names[index] or f"カメラ {index}",
                "available": False,
            })
        _set_progress(current=index + 1)
        # 見つかった分は随時公開(ハングしていても既に分かったカメラは表示できる)
        _detect_partial = list(devices)

    # デバイス名の付与(OS列挙順とOpenCVインデックス順の一致は保証されないためベストエフォート)
    _set_progress(stage="デバイス名を取得中…", current=total - 1)
    if platform.system() == "Windows":
        for device in devices:
            index = device["index"]
            if index < len(os_names) and os_names[index]:
                device["name"] = os_names[index]
    else:
        names = _friendly_names_linux()
        for device in devices:
            if device["index"] in names:
                device["name"] = names[device["index"]]

    with _detect_lock:
        _detect_cache["at"] = time.monotonic()
        _detect_cache["devices"] = devices
    _detect_partial = list(devices)
    _set_progress(state="done", stage="完了", current=total, finished_at=time.monotonic())


def acquire(index):
    """ストリーム用にキャプチャを開く(視聴者数を管理)。開けなければFalse

    「開く」処理は他カメラが使用中だと数十秒ハングすることがあるため、
    `_streams_lock` を持たずにやる(ハングが他の要求まで巻き込むのを防ぐ)。
    """
    cv2, _ = _load_cv2()
    if cv2 is None or not 0 <= index < _max_devices():
        return False
    with _streams_lock:
        stream = _streams.get(index)
        if stream is not None:
            stream["viewers"] += 1
            return True

    # MSMF で映像を返さないカメラも別バックエンドで取れるため総当たりする(ロック外)
    cap, backend_name, frame = _open_capture(cv2, index)
    if cap is None:
        return False
    with _streams_lock:
        existing = _streams.get(index)
        if existing is not None:
            # 開いている間に別スレッドが確保していた → 余分に開けた方は閉じる
            existing["viewers"] += 1
            cap.release()
            return True
        _streams[index] = {
            "cap": cap,
            "lock": threading.Lock(),
            "viewers": 1,
            "holds": 0,
            "info": _capture_info(cap, index, backend_name),
        }
        return True


def read_jpeg(index, quality=80):
    """1フレームgrabしてJPEGバイト列を返す(失敗時はNone)"""
    cv2, _ = _load_cv2()
    if cv2 is None:
        return None
    with _streams_lock:
        stream = _streams.get(index)
    if stream is None:
        return None
    with stream["lock"]:
        ok, frame = stream["cap"].read()
        if not ok or frame is None:
            return None
        encoded, buf = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
        if not encoded:
            return None
        return buf.tobytes()


def read_frame(index):
    """1フレームをBGRのndarrayで返す(リアルタイムAI解析用。失敗時はNone)"""
    cv2, _ = _load_cv2()
    if cv2 is None:
        return None
    with _streams_lock:
        stream = _streams.get(index)
    if stream is None:
        return None
    with stream["lock"]:
        ok, frame = stream["cap"].read()
        if not ok or frame is None:
            return None
        return frame


def release(index):
    """視聴者1名の切断時に呼ぶ。視聴者0かつ解析中も無くなったらキャプチャを閉じる

    解析スレッドが `cap.read()` 中に他スレッドが `cap.release()` すると
    native層で use-after-free(プロセスごとクラッシュ)し得るため、
    解析中(`holds`が0より大きい)間は閉じずに待つ。
    """
    cap = None
    with _streams_lock:
        stream = _streams.get(index)
        if stream is None:
            return
        stream["viewers"] -= 1
        if stream["viewers"] > 0:
            return
        if stream.get("holds", 0) > 0:
            return  # 解析スレッドが使い終わったら unhold 側で閉じる
        cap = stream.pop("cap", None)
        _streams.pop(index, None)
    if cap is not None:
        cap.release()


def hold(index):
    """解析スレッドがこのキャプチャを使い始めることを宣言する"""
    with _streams_lock:
        stream = _streams.get(index)
        if stream is None:
            return False
        stream["holds"] = stream.get("holds", 0) + 1
        return True


def unhold(index):
    """解析スレッドが使い終わった宣言。視聴者も0ならここで閉じる"""
    cap = None
    with _streams_lock:
        stream = _streams.get(index)
        if stream is None:
            return
        stream["holds"] = max(0, stream.get("holds", 0) - 1)
        if stream["holds"] > 0 or stream["viewers"] > 0:
            return
        cap = stream.pop("cap", None)
        _streams.pop(index, None)
    if cap is not None:
        cap.release()
