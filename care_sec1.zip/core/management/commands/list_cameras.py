"""カメラデバイス総点検管理コマンド

Windows はバックエンド(MSMF / DSHOW)ごとにインデックスの割当順が違い、
さらに OpenCV の MSMF は使えないインデックスで約60秒ハングすることがある。
「2台あるはずなのに1台しか出ない」を切り分けるため、
OS列挙と各バックエンド/各インデックスの結果を全部表示する。

使い方:
    python manage.py list_cameras
    python manage.py list_cameras --shots      # 写っている画像も media/camtest/ に保存
"""
import time
from pathlib import Path

from django.core.management.base import BaseCommand

BACKEND_NAMES = ("MSMF", "DSHOW", "ANY")


class Command(BaseCommand):
    help = "接続カメラを一覧し、バックエンド別の開ける/映像が取れる結果を表示する"

    def add_arguments(self, parser):
        parser.add_argument(
            "--shots",
            action="store_true",
            help="読めたフレームを media/camtest/ にJPEG保存する(どれがどのカメラか確認用)",
        )
        parser.add_argument(
            "--max",
            type=int,
            default=4,
            help="試すインデックスの数(既定 4)",
        )

    def handle(self, *args, **options):
        import cv2
        import subprocess

        max_index = options["max"]
        shots_dir = None
        if options["shots"]:
            from django.conf import settings

            shots_dir = Path(settings.MEDIA_ROOT) / "camtest"
            shots_dir.mkdir(parents=True, exist_ok=True)

        self.stdout.write(f"OpenCV {cv2.__version__}")

        self.stdout.write("\n=== OS列挙(PnP: Camera / Image) ===")
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "Get-PnpDevice -Class Camera, Image -PresentOnly -ErrorAction SilentlyContinue | "
             "Select-Object -ExpandProperty FriendlyName"],
            capture_output=True, text=True, timeout=30,
        )
        names = [line.strip() for line in proc.stdout.splitlines() if line.strip()]
        if names:
            for i, name in enumerate(names):
                self.stdout.write(f"  [{i}] {name}")
        else:
            self.stdout.write(self.style.WARNING("  (取得できませんでした)"))

        backends = [(n, getattr(cv2, f"CAP_{n}")) for n in BACKEND_NAMES if hasattr(cv2, f"CAP_{n}")]

        self.stdout.write("\n=== バックエンド別の開ける/映像が取れる ===")
        found = []
        for backend_name, backend in backends:
            self.stdout.write(f"\n-- {backend_name} --")
            for index in range(max_index):
                t0 = time.monotonic()
                cap = cv2.VideoCapture(index, backend)
                opened = cap.isOpened()
                shape = None
                saved = ""
                if opened:
                    for _ in range(3):
                        ok, frame = cap.read()
                        if ok and frame is not None:
                            shape = frame.shape
                            if shots_dir is not None:
                                path = shots_dir / f"{backend_name}_{index}.jpg"
                                cv2.imwrite(str(path), frame)
                                saved = path.name
                            break
                        time.sleep(0.2)
                dt = time.monotonic() - t0
                cap.release()
                if shape:
                    found.append((backend_name, index, shape))
                    mark = self.style.SUCCESS("映像OK")
                elif opened:
                    mark = self.style.WARNING("開いたが映像なし")
                else:
                    mark = "開けない"
                self.stdout.write(
                    f"  index {index}: {mark}  {'' if shape is None else f'{shape[1]}x{shape[0]}'}  {dt:.2f}s  {saved}"
                )

        self.stdout.write("\n=== 結果 ===")
        if found:
            seen = set()
            for backend_name, index, shape in found:
                if index in seen:
                    continue
                seen.add(index)
                self.stdout.write(f"  使用可能: index {index} ({backend_name} / {shape[1]}x{shape[0]})")
            self.stdout.write(
                f"\n  映像を取できたインデックス数: {len({i for _b, i, _s in found})} / OS列挙 {len(names)} 台"
            )
            self.stdout.write(
                "  ※ バックエンドで割当順が違うため、/debug/camera/ の検知は MSMF→DSHOW の順に試します。"
            )
        else:
            self.stdout.write(self.style.ERROR("  どのインデックスからも映像を取できませんでした(他アプリ使用中/プライバシー設定を確認)"))
