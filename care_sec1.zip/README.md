# CARE SEC 転倒・異常検知システム(検証環境)

介護施設の利用者の転倒・異常をAIカメラで検知するWebツールです。
Django **6.1.2** / Python **3.13** / SQLite でセットアップ済みです。

## 起動方法

```powershell
cd C:\Users\student\code\ai2
.venv\Scripts\Activate.ps1     # venvを有効化(しなくても .venv\Scripts\python.exe 直指定でもOK)
python -m pip install -r requirements-windows.txt   # 初回のみ(依存ライブラリの導入)
python manage.py runserver 127.0.0.1:8000
```

依存ライブラリの導入には **tensorflow / mediapipe を含むため数分と数百MB** を要します
(`.venv` には導入済み)。Linux本番環境は `requirements.txt` を参照してください。

### requirements.txt / requirements-windows.txt の同期状態(2026-11-09 検証)

| パッケージ | Windows開発(実venvと一致) | Linux本番 |
|---|---|---|
| Django / asgiref / sqlparse / tzdata | 6.1.2 / 3.12.1 / 0.6.0 / 2026.5 | 同一 |
| opencv-contrib-python | 5.0.0.93 | 同一 |
| mediapipe / pillow / imageio-ffmpeg | 0.10.32 / 12.3.0 / 0.8.1 | 同一 |
| pandas / scikit-learn(再学習用) | 3.1.1 / 1.9.1 | 同一 |
| **tensorflow** | **2.21.0** | **2.20.0** |
| gunicorn | —(不要) | 23.0.0 |

- **意図した差分は tensorflow のみ**。`2.21.0` には **Linux用wheelが存在しない**(Linuxの最新は2.20.0)ため、
  本番は 2.20.0、開発のWindowsは 2.21.0 を使います(同一APIで動作)
- 検証方法: `pip install --dry-run --only-binary=:all: --platform <win_amd64|manylinux_*> --python-version 3.12/3.13 -r <file>`
  → Linux(py3.12/3.13)・Windows(cp313)の3通りで解決OK
- アプリのimport走査結果: `django / cv2 / PIL / numpy / tensorflow / mediapipe / imageio_ffmpeg` — すべて記載済み(`numpy`はTF/mediapipeの推移依存)
- **py-spy** は開発venvにのみ入っている調査用ツール(アプリ動作に不要、本番では入れない)

ブラウザで <http://127.0.0.1:8000/> を開く。
ローカルネットワークからは `runserver 0.0.0.0:8000` で公開できます(防火墙設定が必要)。

## ログインアカウント(デモデータ)

| ユーザー名 | パスワード | 役割 |
|---|---|---|
| `staff1` | `demo1234` | 山田 花子(介護スタッフ) |
| `staff2` | `demo1234` | 佐藤 二郎(介護スタッフ) |
| `admin`  | `admin1234` | 管理画面(`/admin/`)も利用できる介護士 |

## 権限・グループ機能について(廃止済み)

本システムは**介護士のみが使用する**前提のため、権限機能を全面的に撤去しています。

| 項目 | 実装 |
|---|---|
| ユーザーモデル | `core.User`(Django標準User不使用)。`is_superuser` / `groups` / `user_permissions` を**持たない** |
| 認証 | `core.auth.CareWorkerBackend`(権限に依存しない専用バックエンド) |
| 管理画面 | `core.admin.CareSecAdminSite`。**ログイン中の介護士全員が同等にアクセス可能**(閲覧/追加/変更/削除の権限チェックは全て無効化) |
| 権限レコード | 全モデルに `default_permissions = ()` を設定し、`auth_permission` に**業務モデルの権限行を生成しない** |
| ユーザー追加 | `/admin/core/user/add/` から実施(パスワードはハッシュ化して保存) |

残る `django_content_type` / `auth_permission` / `auth_group` テーブルは
Djangoフレームワーク内部(管理画面の操作ログ用)のため残りますが、
**当システムの権限判定には一切使用していません**。

## 便利な管理コマンド

```powershell
python manage.py seed_demo           # 検証用デモデータを投入(カメラ4台/利用者6名/異常8件/録画4本/報告2件)
python manage.py seed_demo --reset   # デモデータを削除して再投入
python manage.py verify_pages        # 全ページ+「対応→解決→報告」フローの自動検証
```

## データベースについて

| 項目 | 内容 |
|---|---|
| DBファイル | `db.sqlite3`(SQLite) |
| 暗号化 | **テスト中は暗号化しない**(平文のまま運用) |
| 暗号化する場合 | `python encrypt_db.py encrypt` / 復号は `python encrypt_db.py decrypt` |
| グループ関連テーブル | `auth_group` / `auth_group_permissions` は**削除済み**(未使用のため) |

### テーブル構成(全13個)

**業務データ(本システム)**

| テーブル | 行数 | 目的 |
|---|---|---|
| `core_user` | 3 | 介護士アカウント。権限列なし |
| `core_camera` | 4 | 監視カメラ台帳(名前/設置場所/online) |
| `core_resident` | 6 | 介護施設の利用者名簿 |
| `core_alert` | 8 | 異常検知の記録(種別/状況/信頼度/時刻ログ/対応者) |
| `core_recording` | 4 | 自動録画(検知前後の映像とAI検知マーク) |
| `core_alertreport` | 2 | 解決報告(誰だったか/身体的問題/対応内容/コメント) |
| `core_persondetection` | 65 | AIのライブ人物検知状態(揮発性) |
| `core_aisettings` | 1 | AI検知パラメータ(シングルトン/誤検知FBで自動調整) |

**Djangoフレームワーク(内部管理用)**

| テーブル | 行数 | 目的 |
|---|---|---|
| `django_content_type` | 13 | モデルのレジストリ(管理画面の操作ログのFK先) |
| `auth_permission` | 20 | Django内部の権限定義。`migrate` 実行時に再生成されるため**削除不可**(当システムの判定には不使用) |
| `django_admin_log` | 1 | 管理画面の操作履歴(誰が何を変更したか) |
| `django_session` | 8 | ログインセッション |
| `django_migrations` | 19 | 適用済みマイグレーションの履歴 |

## アドレス(URL)一覧

| アドレス | 内容 |
|---|---|
| `/` | ダッシュボード |
| `/accounts/login/` `/accounts/logout/` | ログイン / ログアウト |
| `/accounts/profile/` | プロフィール+解決報告入力 |
| `/alerts/` | 異常検知(対応する / 解決・報告を入力) |
| `/recordings/` `/recordings/<id>/` | 自動録画の一覧 / 再生 |
| `/api/alerts/` | リアルタイム通知用JSON(5秒ポーリング) |
| `/admin/` | Django管理画面 |
| `/debug/camera/` | カメラデバッグ(デバイス一覧・ライブ表示) |
| `/debug/camera/devices/` | カメラデバイス一覧JSON |
| `/debug/camera/ai/` | リアルタイムAI解析の状態JSON |
| `/debug/camera/stream/` | MJPEGストリーム(AI解析overlay付き) |

詳細なURL設計・コンテキスト変数の仕様は **URLS.md** を参照してください。

## リアルタイムAI解析の統合(caregiver_safety)

`/debug/camera/` のライブ表示に、介護者安全監視システム **caregiver_safety** の
リアルタイム判定パイプラインをそのまま載せています。

```
カメラ → MediaPipe Pose(33ランドマーク) → 直近30フレームの姿勢系列(99値)
       → 転倒判定LSTM / 状態判定LSTM
       → 骨格・判定overlayを描画してMJPEG配信
       → 転倒確定 / 無動作継続で Alert を作成(既存の通知フローへ)
```

### 仕組み

| 項目 | 実装 |
|---|---|
| 解析本体 | `core/ai_engine.py`(**カメラ1台につき1スレッド**。`_CameraRuntime` が台数分並び、`RealtimeAIEngine` がまとめて管理) |
| 常時稼働 | `AI_ALWAYS_ON = True`(既定)で **runserver 起動時に検知できた全カメラ**の解析を開始。`/debug/camera/` を開かなくても・映像を「停止」しても異常検知と録画は動き続けます(`core/apps.py` がサーバー本体プロセスでのみ起動。後から差し込まれたカメラは定期スキャンで自動追加) |
| 映像の入出力 | `core/camera_service.py` のキャプチャを共有(カメラ毎に独立)。解析済みJPEGを `/debug/camera/stream/?device=N` が配信 |
| デバイス検知 | **非同期**(検知は別スレッド)。`/debug/camera/devices/` は待たずに `{"pending": true}` を返し、`/debug/camera/progress/` を400msポーリングして進行バー+既に分かったカメラを先に表示 |
| モデル | `ai_models/`(caregiver_safety からコピー。詳細は `ai_models/README.md`)。Kerasモデルは全カメラ共有(推論はロックで直列化)、MediaPipe はスレッドセーフではないため **カメラごとに1個** 生成 |
| 状態表示 | `/debug/camera/ai/` を1秒ポーリング(`static/js/debug_camera.js`)。**`?device=N` でそのカメラ**、無しは最も稼働中のカメラ。ページ下部に「全カメラの稼働状況」一覧 |
| 依存ライブラリ | tensorflow / mediapipe / pillow / **imageio-ffmpeg**(H.264 mp4書き出し用。`requirements*.txt` に追加済み) |

### 異常検知(ai2 の方式)

| 検知 | Alert種別 | 条件 |
|---|---|---|
| 転倒 | `fall` | 転倒確率が **AI設定の転倒検知信頼度閾値**(既定0.75)以上で `FALL_CONFIRM_COUNT = 3` 回連続 |
| 無動作 | `suspicious` | ランドマークの移動がほぼゼロで **AI設定の無動作検知秒数**(既定30秒)以上 |

作成した `Alert` はデモ用AIと同じテーブル(`core_alert`)に載るため、
**`/api/alerts/` の5秒ポーリング → 通知音・トースト・OS通知 → 異常検知一覧の対応/解決/報告**
がそのまま機能します。クールダウンは `AISettings.cooldown_seconds`(**現状10秒**で運用。既定モデル値は300秒)を適用します。

### 異常検知からの自動録画

検知(転倒・無動作)を確認した時点で **`AI_RECORDING_SECONDS`(既定8秒)間**フレームを確保し、
H.264 mp4 + サムネイルとして `media/recordings/` に書き出したうえ `Recording` を作成します。

- 録画中は `/debug/camera/` の「自動録画」欄に残り秒数が表示されます
- 書き出しは別スレッド(`ai-recording-writer`)で行うため、解析レート(約10fps)は落ちません
- 作成された録画は **異常検知一覧・詳細の「🎞 検知瞬間の録画を再生」リンク**や `/recordings/` から再生できます
- mp4は `MEDIA_ROOT`(`BASE_DIR / "media"`)へ保存し、`/media/` URLで配信します(`DEBUG=True` のみ)

アラートの紐づけ先カメラは `settings.AI_ALERT_CAMERA_ID` で指定でき、
未指定の場合はデバイスごとに「ライブカメラ0」等を自動作成します。

### 設定(config/settings.py)

| 設定 | 既定 | 内容 |
|---|---|---|
| `AI_REALTIME_ENABLED` | `True` | `False` にすると従来どおり生カメラ映像のみ |
| `AI_MODEL_DIR` | `BASE_DIR / "ai_models"` | モデルの格納先 |
| `AI_ANALYSIS_FPS` | `10` | 解析レート上限 |
| `AI_JPEG_QUALITY` | `80` | 配信JPEG品質 |
| `AI_ALERT_CAMERA_ID` | `None` | アラート紐づけカメラ(未指定=自動作成) |
| `AI_SIMULATOR_ENABLED` | `True` | デモ用AIシミュレーター(`core/ai_simulator.py`)を動かすか |
| `AI_ALWAYS_ON` | `True` | 画面を開いていなくても常時解析するか(runserver起動時に自動開始) |
| `AI_ALWAYS_DEVICES` | `None` | 常時稼働の対象index一覧(**None=検知できた全カメラを同時解析**) |
| `AI_ALWAYS_RETRY_SECONDS` | `30` | 常時稼働の再スキャン間隔(後差し込みカメラを自動追加 / 未接続でもアプリは正常) |
| `AI_FRAME_LOST_SECONDS` | `20` | 映像がこの秒数来ないカメラの解析を止める |
| `AI_STARVED_RETRY_SECONDS` | `300` | 映像を取れなかったカメラの再試行まで抑止 |
| `AI_RECORDING_SECONDS` | `8` | 検知後の録画秒数(0で録画しない) |

> **注意**: `AI_SIMULATOR_ENABLED = True` のうちは、ランダムに発生するデモ通知と
> 実カメラの解析結果が**混在**します。統合の検証時は `False` にしてください。

### 実装上の注意

- 推論は `tf.function` でグラフ化しており1フレーム約10ms。
  `model.predict()` のままだと約160ms/フレームで約1fpsしか出ません。
- tensorflow / mediapipe が無い環境でもアプリは起動でき、
  理由は `/debug/camera/` の「リアルタイムAI解析」欄に表示されます。
- **overlay描画はWebアプリの応答を巻き込まないこと**(実測で site が応答不能になった):
  - 日本語overlayは **1フレーム1回のPIL往復**にまとめて描画(`_draw_japanese_overlay`)。
    行ごとに BGR→RGB→PIL→BGR をやると5回の画像変換になり、解析スレッドがGILを握り続けて
    HTTPリクエストが詰まります(縁取りは `stroke_width` を使う)
  - **誰も映像を見ていない時(常時稼働の自己視聴のみ)は描画とJPEG化を省略**し、
    検知だけ続けてCPU/GILをWeb側へ空けます(`_has_browser_viewer()`)
- **runserver の二重起動防止**: 2プロセスが同じポート(Windowsは `SO_REUSEADDR` で
  重複bindできてしまう)で立つと、両方の常時稼働がカメラを奪い合って互いにハングします。
  `.ai_always_on.lock`(PIDファイル)で先取したプロセスだけが常時稼働を開始します。
- `camera_service.acquire()` は**カメラ開き(最大数十秒ハングし得る)をロック外**で実行します。
- **カメラ未接続は正常な状態**です: 検知は空一覧を返し、常時稼働は待機して
  `AI_ALWAYS_RETRY_SECONDS` 毎に再試行、接続されると自動で開始します。

### カメラ検知(Windows)の落とし穴と対策

同じカメラでも **OpenCV のバックエンドごとにインデックスの割当順と起動速度が違う**ため、
「2台接続しているのに1台しか出ない」が起こり得ます(実測):

| 方法 | index 0 | index 1(内蔵カメラ) |
|---|---|---|
| MSMF | 0.7秒で映像OK | **54秒ハング**してから映像OK |
| DSHOW | 0.7秒で映像OK | **0.4秒**で映像OK |

さらに **開く順序が結果を左右します**(実測):

| 開放順 | 結果 |
|---|---|
| index 0 → 1 | 1台目は30fps、**2台目は開けない(または1fps)** |
| index 1 → 0 | **両方開き、両方からフレームが取れる**(1台目30fps / 2台目1fps) |

つまりこのPCは **2台同時だとUSB帯域が足りない**(解像度を320×240に落としても改善せず、
バックエンドを分けても同じ)。ソフトウェア側でできることは以下です:

1. **バックエンドは DSHOW → MSMF の順**(速い方优先。DSHOW が見えないカメラだけ MSMF)
2. **1インデックス6秒の時間予算**(`_probe_with_budget`)。ハングしたら待つのをやめる
3. **OS列挙(PnP)フォールバック**: OpenCV で開けなくても OS が認識していれば一覧に出す
4. **検知の非同期化**: `/debug/camera/devices/` は待たず `{"pending": true}` を返し、
   進捗APIが既に分かったカメラを随時返す(実測 63秒/1台 → 3秒/2台)
5. **常時稼働は index の降順に全カメラを開く**(`RealtimeAIEngine.target_devices()`)
   → 同時に開ける台数が最大になる順
6. **映像を1コマも渡さないカメラは見張りが止める**(`_monitor_loop`)
   他カメラの帯域を奪ったまま掴んでおくのを避け、`AI_STARVED_RETRY_SECONDS` あけで再試行
   (`cap.read()` が長時間ブロックすると解析ループ内のタイムアウトが発火しないため別スレッド)

> **運用の注意**: 2台以上を安定して同時解析するには、カメラを**別のUSBコントローラ**に
> 分散して接続してください(ハブに纏めない)。同一コントローラだと上の実測どおり
> 2台目が飢えます。

調査用コマンド: `python manage.py list_cameras --shots`
(OS列挙 + バックエンド×インデックスの総当たり + 実際に写った画像を `media/camtest/` に保存)

## AIモデルの再学習(追加学習)

caregiver_safety の学習パイプラインを ai2 に移植し、**サーバー起動時に自動で走る**ようにしました
(`core/retraining.py`)。コマンドは手動実行・検証用の逃げ道として残しています。

### 起動時の自動再学習(`AI_AUTO_RETRAIN = True`)

```powershell
python manage.py ai_collect_data     # 材料を増やすのはこれだけ(またはCSVを train_data/ に置く)
python manage.py runserver ...       # 次回起動時に 前処理→学習→現行と比較→反映 を自動で実行
```

`runserver` 起動時に `train_data/*.csv` の**指紋(ファイル名・サイズ・更新時刻のハッシュ)**を
`train_dataset/retrain_state.json` と比較し、次のように動きます。

| 状況 | 動作 |
|---|---|
| データが変わっていない | **数秒で素通り**(ログ `[Retrain] データ変更なし(Nファイル)`)。autoreload の再起動でも安全 |
| データ変更あり / モデル未作成 | データセット再生成 → 候補を `ai_models/candidates/` へ学習 → **同じ保持データで現行と比較** → 劣化がなければ `ai_models/` へ反映(旧モデルは `ai_models/backup/<日時>/` へ自動退避) → 指紋を記録 |
| 候補が現行より劣る | **反映を見送り**候補だけ残す(acc・見逃し率を両方ログ表示) |
| 学習中の例外 | 現行モデルはそのまま。Webアプリと解析は止めずログのみ |

- 反映判定は **AI設定の転倒閾値での 正解率 / 誤検知率 / 見逃し率** の3指標。許容する劣化幅は `AI_RETRAIN_PROMOTE_MARGIN`(既定 0.005)
- 学習は **常時稼働を開始する前** に走らせる(CPU争避のため。時間がかかるのはデータ追加時のみ)
- `/debug/camera/` のAIカード下に「自動再学習 最終: … / 転倒モデル更新…」と表示
- 設定: `AI_AUTO_RETRAIN` / `AI_RETRAIN_EPOCHS_FALL` / `AI_RETRAIN_EPOCHS_STATE` / `AI_RETRAIN_PROMOTE_MARGIN`
- 手動確認・実行: `python manage.py ai_retrain --status` / `--force`

### コマンドで手動で行う場合

```powershell
python manage.py ai_collect_data            # ① 収集:カメラ→MediaPipe Pose→train_data/*.csv
python manage.py ai_prepare_dataset         # ② 前処理:CSV→train_dataset/X.npy,y.npy(転倒)
python manage.py ai_prepare_state_dataset   # ② 前処理:CSV→state_X/state_y/state_labels(状態)
python manage.py ai_train_fall              # ③ 学習:ai_models/candidates/ へ(現行は壊れない)
python manage.py ai_train_state
python manage.py ai_check_model             # ④ 検証:精度/混同行列/CSV別誤判定/AI設定閾値での評価
python manage.py ai_train_fall --promote    # ⑤ 反映:旧モデルは ai_models/backup/<日時>/ へ退避
python manage.py runserver 127.0.0.1:8000   # ⑥ 再起動(モデルは起動時にキャッシュされる)
```

| コマンド | 内容 |
|---|---|
| `ai_collect_data` | 姿勢データ収集。`--device` / `--backend dshow` / `--label normal\|fall` / `--name 行動名` / `--seconds` / `--no-gui`。**runserverを止めてから**実行(カメラ占有と衝突する) |
| `ai_prepare_dataset` | `train_data/*.csv` → `train_dataset/X.npy,y.npy`。`--stride`(既定5) `--dry-run` |
| `ai_prepare_state_dataset` | → `state_X.npy,state_y.npy,state_labels.npy`。`--list-unmapped` で未登録の行動名を確認 |
| `ai_train_fall` / `ai_train_state` | LSTM再学習(状態はクラス重み付き)。`--epochs --batch-size --promote` |
| `ai_check_model` | 検証。`--model fall\|state` `--path <keras>` `--threshold`(既定=AI設定の転倒閾値) `--top` |

- 材料の格納先: `train_data/`(姿勢CSV 39個 = fall 13 / normal 26)、`train_dataset/`(学習テンソル)
  ※ caregiver_safety の `data/`・`dataset/` をコピー済み。元ファイルは `train_dataset/_caregiver_original/` に退避してあります
- 新しい行動CSVを状態学習に使うには `core/training.py` の `STATE_BY_SUFFIX` へ登録します
- **`--promote` 後はサーバー再起動が必要**(モデルは初回使用時にメモリへキャッシュされるため)

### 現行モデルの検証結果(参考・`ai_check_model` 実測)

AI設定の閾値 **0.77** で 2,288 シーケンスを検証:

| 指標 | 値 |
|---|---|
| 正解率 | 96.68%(2212/2288) |
| 誤検知率(NORMALがFALL扱い=アラート空振り) | **0.26%**(5件) |
| 見逃し率(FALLがNORMAL扱い=危険) | **18.88%**(71件) |

`fall_歩行中に転倒…` 系のCSVで誤判定率 59〜91% と高く、**追加学習で最も効くのは「見逃し」側**
です。`ai_collect_data --label fall` で該当動作を追加収集して再学習してください。

## 構成

```
config/        … settings / urls(全URLは config/urls.py に集約)
core/          … models / views / admin / auth / ai_engine(全カメラ常時解析) / camera_service
                 / training(再学習の共通処理) / management commands
ai_models/     … 推論モデル + candidates/(学習候補) + backup/(反映前の旧モデル)
train_data/    … 追加学習の材料: 姿勢CSV(33landmark×xyz=99値 + ラベル + 人物番号)
train_dataset/ … 学習入力テンソル(X/y, state_X/state_y/state_labels)
templates/     … 画面テンプレート(base.html が情報バー+メニュー+MAINの共通レイアウト)
static/        … css / js / img
media/         … AI自動録画(mp4 / jpg) などアップロード系
db.sqlite3     … SQLiteデータベース
```

## 動作のポイント

- **異常検知タブ**で「対応する」を押すと対応者が確定し、`/api/alerts/` ポーリングにより
  開いている全画面に「誰が対応中か」が自動反映されます(新規異常は通知音+トースト)。
- 対応者本人だけが「解決・報告を入力」を押せ、プロフィールページの報告フォームへ遷移します。
- 録画再生ページにはAI検知マーク(例: 「転倒の瞬間 00:18」)があり、クリックでその瞬間へジャンプします。

