/**
 * CARE SEC カメラデバッグページ(static/js/debug_camera.js)
 * - サーバーマシン接続カメラの検知一覧表示と選択
 * - MJPEGストリームの開始/停止
 */
(function () {
  "use strict";

  var root = document.getElementById("debug-camera");
  if (!root) {
    return;
  }

  var devicesUrl = root.dataset.devicesUrl;
  var progressUrl = root.dataset.progressUrl;
  var streamUrl = root.dataset.streamUrl;

  var statusEl = document.getElementById("device-status");
  var listEl = document.getElementById("device-list");
  var emptyEl = document.getElementById("device-empty");
  var errorEl = document.getElementById("device-error");
  var refreshBtn = document.getElementById("device-refresh");

  var progressEl = document.getElementById("detect-progress");
  var progressBar = document.getElementById("detect-progress-bar");
  var progressLabel = document.getElementById("detect-progress-label");
  var progressPercent = document.getElementById("detect-progress-percent");
  var progressTimer = null;

  var imgEl = document.getElementById("stream-img");
  var placeholderEl = document.getElementById("stream-placeholder");
  var streamStatusEl = document.getElementById("stream-status");
  var streamMetaEl = document.getElementById("stream-meta");
  var startBtn = document.getElementById("stream-start");
  var stopBtn = document.getElementById("stream-stop");

  var devices = [];
  var selected = null;
  var streaming = false;

  function formatDevice(device) {
    if (device.busy) {
      return "使用中のため映像を確認できません(選択するとAIがこのカメラへ切り替わります)";
    }
    if (device.available === false) {
      return "開けるが映像なし(他アプリ使用中の可能性)";
    }
    var size = device.width && device.height ? device.width + "×" + device.height : "解像度不明";
    var fps = device.fps ? " / " + device.fps + "fps" : "";
    var backend = device.backend ? " / " + device.backend : "";
    var inUse = device.in_use ? " / 配信中" : "";
    var url = device.url ? " / " + device.url : "";
    return size + fps + backend + inUse + url;
  }

  function renderDevices() {
    listEl.innerHTML = "";
    devices.forEach(function (device) {
      var li = document.createElement("li");
      var button = document.createElement("button");
      button.type = "button";
      var unavailable = device.available === false && !device.busy;
      button.className = "debug-device" + (unavailable ? " is-unavailable" : "") + (device.busy ? " is-busy" : "");
      button.dataset.index = String(device.index);

      // 検知時に見た実フレームのサムネイル(どれがどのカメラか目視確認できる)
      if (device.snapshot_url) {
        var thumb = document.createElement("img");
        thumb.className = "debug-device__thumb";
        thumb.src = device.snapshot_url;
        thumb.alt = "index " + device.index + " の映像";
        thumb.loading = "lazy";
        // CSS依存だとブラウザのスタイルシートキャッシュで原寸表示になりレイアウトが崩れるため、
        // インラインで確定させる
        thumb.width = 88;
        thumb.height = 66;
        thumb.style.cssText = "width:88px;height:66px;object-fit:cover;flex:0 0 auto;" +
          "border:1px solid #cfd5db;border-radius:4px;background:#1f2328;";
        button.appendChild(thumb);
      }

      var indexEl = document.createElement("span");
      indexEl.className = "debug-device__index";
      indexEl.textContent = device.kind === "ip" ? "IP" : "index " + device.index;

      var nameEl = document.createElement("span");
      nameEl.className = "debug-device__name";
      nameEl.textContent = device.name;

      var metaEl = document.createElement("span");
      metaEl.className = "debug-device__meta";
      metaEl.textContent = formatDevice(device);

      button.appendChild(indexEl);
      button.appendChild(nameEl);
      button.appendChild(metaEl);
      button.addEventListener("click", function () {
        // busy(他カメラ使用中で映像未確認)は、選択時にAIが切り替えて開けるので選択可
        if (device.available === false && !device.busy) {
          streamMetaEl.textContent = "index " + device.index + " は映像を取得できませんでした(他アプリを閉じて再検知してください)。";
          return;
        }
        selectDevice(device);
      });
      // IPカメラは index が "cam:3" のようなキーなので文字列で比較する
      button.dataset.key = String(device.index);
      li.appendChild(button);
      listEl.appendChild(li);
    });
    listEl.hidden = devices.length === 0;
    // 検知中は「0件」でも空欄メッセージを出さない
    emptyEl.hidden = devices.length !== 0 || detectPending;
  }

  function selectDevice(device) {
    selected = device;
    listEl.querySelectorAll(".debug-device").forEach(function (el) {
      el.classList.toggle("is-selected", el.dataset.key === String(device.index));
    });
    startBtn.disabled = streaming;
    var label = device.kind === "ip" ? "IP " + device.index : "index " + device.index;
    streamMetaEl.textContent = "選択中: " + device.name + " (" + label + ") / " + formatDevice(device);
  }

  function setStreamStatus(text, tone) {
    streamStatusEl.textContent = text;
    streamStatusEl.className = "chip" + (tone ? " chip--" + tone : "");
  }

  /* ---------- デバイス検知の進行バー ---------- */
  var detectPending = false;

  function renderDeviceList(list) {
    devices = list || [];
    renderDevices();
    if (selected) {
      var still = devices.find(function (d) {
        return d.index === selected.index;
      });
      if (still) {
        selectDevice(still);
      } else {
        selected = null;
        startBtn.disabled = true;
        streamMetaEl.textContent = "";
      }
    }
  }

  function updateProgress(data) {
    if (!progressEl) {
      return;
    }
    var total = data.total || 0;
    var current = data.current || 0;
    var percent = null;

    if (data.state === "done" || data.state === "error") {
      percent = 100;
    } else if (total > 0) {
      percent = Math.min(99, Math.round((current / total) * 100));
    }

    if (percent === null) {
      // ステップ数が未確定の間は不定進捗(スライドアニメーション)
      progressBar.className = "detect-progress__bar is-indeterminate";
      progressBar.style.width = "";
      progressPercent.textContent = "";
    } else {
      progressBar.className = "detect-progress__bar";
      progressBar.style.width = percent + "%";
      progressPercent.textContent = percent + "%";
    }

    var label = data.stage || "デバイスを検知しています…";
    if (data.state === "running" && total > 0) {
      label += "(" + Math.min(current + 1, total) + "/" + total + ")";
    }
    if (data.elapsed !== null && data.elapsed !== undefined && data.state === "running") {
      label += " / " + data.elapsed + "秒";
    }
    progressLabel.textContent = label;

    // 検知中に見つかった分は先に表示する(1台目の確認が重くても2台目を選べるように)
    if (data.devices && data.devices.length && JSON.stringify(data.devices) !== JSON.stringify(devices)) {
      renderDeviceList(data.devices);
      if (statusEl && !statusEl.hidden) {
        statusEl.textContent = "検知中ですでに分かったカメラを表示しています…";
      }
    }

    // 検知完了を待って最終一覧(デバイス名付き)を取り直す
    if (detectPending && data.state === "done") {
      detectPending = false;
      loadDevices(false);
    }
  }

  function startProgressPolling() {
    if (!progressEl) {
      return;
    }
    progressEl.hidden = false;
    updateProgress({ state: "running", stage: "検知を開始しています…", current: 0, total: 0 });
    if (progressTimer) {
      return;
    }
    progressTimer = window.setInterval(function () {
      fetch(progressUrl, { headers: { Accept: "application/json" } })
        .then(function (res) {
          return res.json();
        })
        .then(updateProgress)
        .catch(function () {
          /* 進捗取得の失敗は表示に影響させない */
        });
    }, 400);
  }

  function stopProgressPolling(finalData) {
    if (progressTimer) {
      window.clearInterval(progressTimer);
      progressTimer = null;
    }
    if (finalData) {
      updateProgress(finalData);
    }
    // 完了表示を見せるため少し置いてからバーを隠す
    window.setTimeout(function () {
      if (progressEl) {
        progressEl.hidden = true;
      }
    }, 700);
  }

  function loadDevices(force) {
    statusEl.hidden = false;
    statusEl.textContent = force ? "デバイスを再検知しています…" : "デバイスを検知しています…";
    errorEl.hidden = true;
    startProgressPolling();
    fetch(devicesUrl + (force ? "?force=1" : ""), { headers: { Accept: "application/json" } })
      .then(function (res) {
        return res.json();
      })
      .then(function (data) {
        if (data.pending) {
          // 検知はバックグラウンド進行中。進捗ポーリングが続き、見つかった分が表示される
          detectPending = true;
          renderDeviceList(data.devices);
          return;
        }
        detectPending = false;
        statusEl.hidden = true;
        stopProgressPolling({ state: "done", stage: "完了", current: 1, total: 1 });
        if (!data.ok) {
          devices = [];
          renderDevices();
          emptyEl.hidden = true;
          errorEl.textContent = data.error || "デバイス検知に失敗しました。";
          errorEl.hidden = false;
          return;
        }
        renderDeviceList(data.devices);
      })
      .catch(function () {
        detectPending = false;
        statusEl.hidden = true;
        stopProgressPolling({ state: "error", stage: "通信エラー", current: 1, total: 1 });
        errorEl.textContent = "デバイス検知APIとの通信に失敗しました。";
        errorEl.hidden = false;
      });
  }

  function startStream() {
    if (!selected || streaming) {
      return;
    }
    streaming = true;
    imgEl.hidden = false;
    placeholderEl.hidden = true;
    imgEl.src = streamUrl + "?device=" + encodeURIComponent(selected.index) + "&t=" + Date.now();
    setStreamStatus("配信中", "resolved");
    startBtn.disabled = true;
    stopBtn.disabled = false;
  }

  function stopStream() {
    streaming = false;
    // MJPEG接続は removeAttribute だけでは切断されないため、src を上書きして
    // ブラウザに読み込みを中断させる(サーバ側のストリーム/解析が止まる)
    imgEl.src = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
    imgEl.removeAttribute("src");
    imgEl.hidden = true;
    placeholderEl.hidden = false;
    setStreamStatus("停止中", "");
    startBtn.disabled = !selected;
    stopBtn.disabled = true;
  }

  imgEl.addEventListener("error", function () {
    if (!streaming) {
      return;
    }
    streaming = false;
    imgEl.hidden = true;
    placeholderEl.hidden = false;
    setStreamStatus("エラー", "open");
    streamMetaEl.textContent = "ストリーム受信に失敗しました。デバイスが他アプリで使用中か、切断された可能性があります。";
    startBtn.disabled = !selected;
    stopBtn.disabled = true;
  });

  refreshBtn.addEventListener("click", function () {
    loadDevices(true);
  });
  startBtn.addEventListener("click", startStream);
  stopBtn.addEventListener("click", stopStream);
  window.addEventListener("beforeunload", stopStream);

  loadDevices(false);

  /* ---------- リアルタイムAI解析の状態表示(1秒ポーリング) ---------- */
  var aiRoot = document.getElementById("ai-status");
  if (!aiRoot) {
    return;
  }

  var aiStatusUrl = aiRoot.dataset.aiStatusUrl;
  var aiChip = document.getElementById("ai-chip");
  var aiState = document.getElementById("ai-state");
  var aiJudge = document.getElementById("ai-judge");
  var aiDanger = document.getElementById("ai-danger");
  var aiFoot = document.getElementById("ai-foot");
  var aiStill = document.getElementById("ai-still");
  var aiFrames = document.getElementById("ai-frames");
  var aiFps = document.getElementById("ai-fps");
  var aiRecording = document.getElementById("ai-recording");
  var aiDevices = document.getElementById("ai-devices");
  var aiDevicesNote = document.getElementById("ai-devices-note");
  var aiRetrainNote = document.getElementById("ai-retrain-note");
  var aiError = document.getElementById("ai-error");
  var aiLastAlert = document.getElementById("ai-last-alert");

  function setAiChip(text, tone) {
    aiChip.textContent = text;
    aiChip.className = "chip" + (tone ? " chip--" + tone : "");
  }

  function setValue(el, text, tone) {
    el.textContent = text;
    el.className = "ai-status-item__value" + (tone ? " is-" + tone : "");
  }

  function renderAiDevices(devices) {
    if (!aiDevices) {
      return;
    }
    var body = aiDevices.querySelector("tbody");
    if (!devices || !devices.length) {
      aiDevices.hidden = true;
      return;
    }
    aiDevices.hidden = false;
    body.innerHTML = "";
    var errors = [];
    devices.forEach(function (row) {
      var tr = document.createElement("tr");
      function cell(text, cls) {
        var td = document.createElement("td");
        td.textContent = text;
        if (cls) {
          td.className = cls;
        }
        tr.appendChild(td);
      }
      var phase = row.phase || "stopped";
      var phaseLabel =
        phase === "running" ? "解析中"
        : (phase === "loading" ? "準備中"
        : (phase === "error" ? "停止" : "待機中"));
      cell(typeof row.device === "number" ? "index " + row.device : "IP " + row.device);
      cell(row.state || "-");
      cell(row.status_label || "-");
      if (row.low_fps) {
        cell((row.fps || 0) + " fps(低速/帯域不足)", "is-warn");
      } else {
        cell(row.fps ? row.fps + " fps" : "-");
      }
      cell(row.still_seconds !== undefined && row.still_seconds !== null ? row.still_seconds + "秒" : "-");
      cell(row.viewers ? row.viewers + "人" : "-");
      cell(phaseLabel, phase === "running" ? "is-ok" : (phase === "error" ? "is-danger" : ""));
      if (row.error) {
        tr.title = row.error;
        errors.push("index " + row.device + ": " + row.error);
      }
      body.appendChild(tr);
    });

    if (aiDevicesNote) {
      aiDevicesNote.hidden = errors.length === 0;
      aiDevicesNote.textContent = errors.join(" / ");
    }
  }

  function renderAiStatus(data) {
    if (data.enabled === false) {
      aiRoot.hidden = true;
      return;
    }
    aiRoot.hidden = false;

    var runningCount = (data.devices || []).filter(function (d) {
      return d.running;
    }).length;

    if (data.phase === "running") {
      var label = runningCount > 1
        ? runningCount + "台を常時解析中"
        : (data.persistent ? "常時解析中 " : "解析中 ") + (data.fps ? data.fps + "fps" : "");
      setAiChip(label, "resolved");
    } else if (data.phase === "loading") {
      setAiChip(data.model_ready ? "準備中" : "モデル読込中", "responding");
    } else if (data.phase === "error") {
      setAiChip("エラー", "open");
    } else if (runningCount > 0) {
      // このカメラは未解析でも、サーバーは他のカメラを常時解析している
      setAiChip("このカメラは待機中(他 " + runningCount + "台は解析中)", "");
    } else {
      setAiChip(data.persistent ? "常時待機中" : "待機中", "");
    }

    aiError.hidden = !data.error;
    if (data.error) {
      aiError.textContent = "AI解析エラー: " + data.error;
    }

    setValue(aiState, data.state || "-");

    var judge = data.status_label || "-";
    var judgeTone = "";
    if (data.status === "FALL !!!" || data.status === "FALL") {
      judgeTone = "danger";
    } else if (data.status === "NORMAL") {
      judgeTone = "ok";
    } else if (data.status && data.status.indexOf("WAITING") === 0) {
      judgeTone = "warn";
    }
    setValue(aiJudge, judge, judgeTone);

    if (data.danger_percent === null || data.danger_percent === undefined) {
      setValue(aiDanger, "--");
    } else {
      var dangerTone = data.danger_percent >= 75 ? "danger" : data.danger_percent >= 50 ? "warn" : "";
      setValue(aiDanger, data.danger_percent.toFixed(2) + "%", dangerTone);
    }

    setValue(aiFoot, data.foot_visible ? "画面内" : "画面外", data.foot_visible ? "ok" : "warn");

    if (data.stillness_threshold) {
      var stillTone = data.still_seconds >= data.stillness_threshold ? "danger" : "";
      setValue(aiStill, data.still_seconds + " / " + data.stillness_threshold + "秒", stillTone);
    } else {
      setValue(aiStill, data.still_seconds + "秒");
    }

    setValue(aiFrames, (data.sequence_frames || 0) + " / 30");
    setValue(aiFps, data.fps ? data.fps + " fps" : "-");

    if (aiRecording) {
      if (data.recording_seconds_left !== null && data.recording_seconds_left !== undefined) {
        setValue(aiRecording, "録画中 " + data.recording_seconds_left + "秒", "danger");
      } else {
        setValue(aiRecording, "待機中");
      }
    }

    if (data.last_alert) {
      var when = data.last_alert.at ? new Date(data.last_alert.at) : null;
      var timeLabel = when && !isNaN(when.getTime()) ? when.toLocaleTimeString() : "";
      aiLastAlert.hidden = false;
      aiLastAlert.textContent =
        "直近のAI検知: " + data.last_alert.kind +
        " / 信頼度 " + Math.round((data.last_alert.confidence || 0) * 100) + "%" +
        (timeLabel ? " (" + timeLabel + ")" : "") +
        " → 異常検知一覧で対応できます";
    } else {
      aiLastAlert.hidden = true;
    }

    renderAiDevices(data.devices);
    renderRetrain(data.retrain);
  }

  /* サーバー起動時の自動再学習の最新結果 */
  function renderRetrain(info) {
    if (!aiRetrainNote) {
      return;
    }
    if (!info) {
      aiRetrainNote.hidden = true;
      return;
    }
    var parts = [];
    if (info.finished_at) {
      parts.push("自動再学習 最終: " + info.finished_at);
    }
    if (info.data_files !== undefined && info.data_files !== null) {
      parts.push("材料 " + info.data_files + "件");
    }
    if (info.fall_promoted === true) {
      parts.push("転倒モデル更新");
    } else if (info.fall_promoted === false) {
      parts.push("転倒モデルは現行維持");
    }
    if (info.state_promoted === true) {
      parts.push("状態モデル更新");
    } else if (info.state_promoted === false) {
      parts.push("状態モデルは現行維持");
    }
    if (info.elapsed_seconds !== undefined && info.elapsed_seconds !== null) {
      parts.push(info.elapsed_seconds + "秒");
    }
    if (info.error) {
      parts.push("エラー: " + info.error);
    }
    aiRetrainNote.textContent = parts.join(" / ");
    aiRetrainNote.hidden = parts.length === 0;
  }

  function loadAiStatus() {
    // 選んでいるカメラの状態を見る(未選択ならサーバーが解析中の最初のカメラ)
    var url = aiStatusUrl;
    if (selected) {
      url += "?device=" + encodeURIComponent(selected.index);
    }
    fetch(url, { headers: { Accept: "application/json" } })
      .then(function (res) {
        return res.json();
      })
      .then(renderAiStatus)
      .catch(function () {
        setAiChip("取得失敗", "open");
      });
  }

  loadAiStatus();
  window.setInterval(loadAiStatus, 1000);
})();
